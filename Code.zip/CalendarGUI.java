import java.util.*;

import javax.swing.*;
import java.awt.*;


//works for dates after january 1, 2020
//handles the gui for the calendar view

public class CalendarGUI {
	private int month; // 0-11
	private int year;

	private static JPanel calendar;
	private GregorianCalendar c;// gets current time, based on user location
	
	/**
	 * String of each month, January to December
	 */
	public static String MONTH[] = { "January", "February", "March", "April", "May",
			"June", "July", "August",
			"September", "October", "November", "December" };
	/**
	 * String of each day of the week, Sunday to Saturday
	 */
	public static String WEEKDAY[] = { "Sunday", "Monday", "Tuesday", "Wednesday",
			"Thursday", "Friday", "Saturday" };
	/**
	 * Number of days in each month
	 */
	public static int DAYS_IN_MONTH[] = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
	
	/**
	 * Creates a CalendarGui object with the date set as the day when the constructor is called
	 */
	public CalendarGUI() {
		// Calendar is a built-in java object and contains one time representation
		// i.e. January 1, 2021 5:13pm
		// this program uses java's built in Calendar objects to handle dates
		c = new GregorianCalendar();// gets current time, based on user location
		month = c.get(Calendar.MONTH);
		year = c.get(Calendar.YEAR);

		calendar = new JPanel();
	}

	// returns day of week i.e. sunday -0,monday-1
	/**
	 * 
	 * @return integer 0-6 of the day of the week on which the first lands on, Sunday to Saturday
	 */
	public int getFirstDayOfMonth() {
		// temp is declared for calculations
		GregorianCalendar temp = (GregorianCalendar) c.clone();

		temp.add(Calendar.DAY_OF_MONTH, -(c.get(Calendar.DAY_OF_MONTH) - 1));

		return temp.get(Calendar.DAY_OF_WEEK) - 1;
	}
	/**
	 * 
	 * @return numbers of days in each month, 29 on a leap year February, else, their normal number of days
	 */
	public int getDaysInMonth() {
		if(c.isLeapYear(year)&&month==2) {
			return 29;
		}
		return DAYS_IN_MONTH[month];
	}
	
	/**
	 * 
	 * @return the String representation of the current month
	 */
	public String getMonth() {
		return MONTH[month];
	}
	
	/**
	 * 
	 * @return the integer representation of the current month, 0-11
	 */
	public int getMonthInt() {
		return month;
	}
	/**
	 * 
	 * @return integer of current month
	 */
	public int getYear() {
		return year;
	}
	// returns the GUI panel for calendar object
	/**
	 * 
	 * @param expenses ArrayList of ArrayList of expenses,
	 *  where the size of the outer arraylist is the number of days in month
	 *  the inner arraylist contains all the expenses due on that day
	 * @return the JPanel containing the user interface to allow for
	 *  switching between months, the expenses due on each day
	 */
	public JPanel getPanel(ArrayList<ArrayList<Expense>> expenses) {
		calendar.removeAll();
		calendar.setLayout(new GridLayout(7,7));
		
		//hardcoded
		calendar.setBounds(0, 100, 1000, 450);
		
		
		for (int i = 0; i < 7; i++) {
			JLabel temp = new JLabel(WEEKDAY[i].substring(0,3));
			temp.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
			calendar.add(temp);
		}
		// adds correct number of blank days before the first day of month
		int count = 0;
		for (int i = 0; i < getFirstDayOfMonth(); i++) {
			count++;
			JLabel temp = new JLabel("");
			temp.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
			calendar.add(temp);
		}
		
		for(int i = 1;i<=getDaysInMonth();i++) {
			count++;
			JLabel dayLabel = new JLabel(i+"");
			JPanel expenseOnDay = new JPanel();
			expenseOnDay.setLayout(new BoxLayout(expenseOnDay,BoxLayout.Y_AXIS));
			expenseOnDay.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
			expenseOnDay.add(dayLabel);
			
			//days of the month in outer for loop is index 1 based
			for(Expense e:expenses.get(i-1)) {
				expenseOnDay.add(new JLabel(e.getName()));
			}
			
			calendar.add(expenseOnDay);
		}
		for(int i = count;i<42;i++) {
			JLabel temp = new JLabel("");
			temp.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
			calendar.add(temp);
		}
		
		calendar.revalidate();
		return calendar;
	}
	
	/**
	 * go forward by one month
	 */
	public void increaseMonth() {
		c.add(Calendar.MONTH, 1);
		month = c.get(Calendar.MONTH);
		year = c.get(Calendar.YEAR);
	}
	/**
	 * go backward by one month
	 */
	public void decreaseMonth() {
		c.add(Calendar.MONTH, -1);
		month = c.get(Calendar.MONTH);
		year = c.get(Calendar.YEAR);
	}
	
	//used for testing purposes
	public static void main(String[] args) {
		CalendarGUI c = new CalendarGUI();
		JFrame main = new JFrame();
		main.setSize(1000, 600);
		main.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		User u = new User();
		main.add(c.getPanel(u.returnMonthlyExpenses(c.month, c.getDaysInMonth())));
		main.setVisible(true);
	}
	
	//parameters day and month are 1 indexed
	//checks for valid yearly billing date 
	//feb 29 is not valid since the expense is yearly
	/**
	 * 
	 * @param day an integer
	 * @param month an integer
	 * @return true if the day month pair form a valid date, false otherwise including leap days
	 */
	public static boolean validDate(int day,int month){
		if(month<1||month>12) return false;
		if(DAYS_IN_MONTH[month-1]>=day) {
			return true;
		}else {
			return false;
		}
	}
}
