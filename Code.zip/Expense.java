import java.util.*;
import java.util.Arrays;

public class Expense {
	private String name;
	private double amount;
	private boolean recurring;
	private int expenseType;//corresponds with the index of type array below
	//1-one time,2-monthly,3-yearly
	private int durationType;
	private int day;//billing/incurring day if recurring, index 0
	private int month;//billing/incurring month,index 0;
	//relevant for one time and yearly expenses
	private int year;
	/**
	 * List of string of predetermined string types
	 */
	public static String [] type = {"Tuition","Rent",
			"Internet/Phone","Food","Utilities","Other"};
	//int expenseType corresponds with the index of type[] array above
	//parameters day is from 1 to maximum number of days in month, 
	//month is from 1-12
	/**
	 * Creates an EXpense object based on the given parameters
	 * @param name string of name of the expense
	 * @param amount cost if expense
	 * @param durationType integer, 1 if one-time, 2 if monthly, and 3 if yearly
	 * @param expenseType integer, representing the index in the string array type
	 * @param day day that the expense is due
	 * @param month month that the expense is due, irrelevant for monthly expenses
	 * @param year year that the expense is due, irrelevant for monthly and yearly expenses
	 */
	public Expense(String name,double amount, int durationType,
			int expenseType,int day,int month,int year){
		this.name=name.replaceAll("_", " ");
		this.amount=amount;
		this.durationType = durationType;
		this.day = -1;this.month=-1;this.year=-1;
		if(this.durationType!=1) {
			recurring = true;
		}else {
			recurring = false;
		}
		this.expenseType = expenseType;
		if(durationType==1) {
			this.day = day-1;this.month = month-1;this.year = year;
		}
		if(durationType==2) {
			this.day = day-1;
		}
		if(durationType==3) {
			this.day=day-1;this.month=month-1;
		}
	}
	
	
	
	/**
	 * Comparator object made for sorting by name. 
	 * @author WenHao
	 *
	 */
	public static class NameCompare implements Comparator<Expense>{
		//does not care about upper lower case
		public int compare(Expense e1,Expense e2){
			if(e1.getName().toLowerCase().compareTo((e2.getName().toLowerCase()))>0){
				return 1;
			}else {
				return -1;
			}
		}
	}
	/**
	 * Comparator object made for sorting by amount
	 * @author WenHao
	 *
	 */
	public static class AmountCompare implements Comparator<Expense>{
		//does not care about upper lower case
		public int compare(Expense e1,Expense e2){
			if(e1.getAmount()>e2.getAmount()) {
				return 1;
			}else {
				return -1;
			}
		}
	}
	
	/**
	 * 
	 * @param a an ArrayList of Expenses
	 * @param c Comparator such as the static Comparator objects in the Expense class
	 */
	public static void sortExpense(ArrayList<Expense> a, Comparator<Expense> c){
		//makes sorting easier
		Expense [] arr = new Expense[a.size()];
		for(int i =0;i<a.size();i++) {
			arr[i] = a.get(i);
		}
		
		sortExpense(arr,0,arr.length,c);
		a.clear();
		for(int i = 0;i<arr.length;i++) {
			a.add(arr[i]);
		}
		
	}
	
	//internal method for mergesort based on given comparator
	//l is leftbound index, r is rightbound index
	//the method sorts starting at and including l, up to but not including r
	private static void sortExpense(Expense [] arr,int l, int r, Comparator<Expense> c) {
		int mid  = (l+r)/2 ;
		if(r-l>=2) {
			sortExpense(arr,l,mid,c);
			sortExpense(arr,mid,r,c);
			merge(arr,l,mid,r,c);
		}
	}
	private static void merge(Expense[] arr,int l, int m, int r,Comparator<Expense> c) {
		int left = 0;
		int right = 0;

		Expense[] leftarr = Arrays.copyOfRange(arr, l, m);
		Expense[] rightarr = Arrays.copyOfRange(arr,m,r);
		
		for(int i = l;i<r;i++) {
			if(left==leftarr.length||right<rightarr.length&&c.compare(leftarr[left],
					rightarr[right])>0) {
				arr[i]=rightarr[right];
				right++;
			}else {
				arr[i] = leftarr[left];
				left++;
			}
		}
	}
	
	/**
	 * 
	 * @return the amount cost of the expense
	 */
	public double getAmount(){
		return amount;
	}
	/**
	 * 
	 * @return string of the name of the expense
	 */
	public String getName() {
		return name;
	}
	/**
	 * 
	 * @return String representation of the expense frequency
	 */
	public String getFrequency() {
		if(durationType==1) {
			return "One-Time";
		}else if(durationType==2) {
			return "Monthly";
		}else {
			return "Yearly";
		}
	}
	/**
	 * 
	 * @return integer of the expense frequency
	 */
	public int getFrequencyInt() {
		return durationType;
	}
	/**
	 * 
	 * @return day the expense is due
	 */
	public int getDay() {
		return day;
	}
	/**
	 * 
	 * @return month the expense is due
	 */
	public int getMonth() {
		return month;
	}
	/**
	 * 
	 * @return year the expense is due
	 */
	public int getYear() {
		return year;
	}
	/**
	 * 
	 * @return true is frequency type is 2 or 3, monthly or yearly, false if 1
	 */
	public boolean isRecurring() {
		return recurring;
	}
	//when created, day and month are both kept 0 indexed, so when stored in file 
	//to re construct the expense, 1 must be added to day and month
	/**
	 * returns the string representation of the object
	 */
	public String toString() {
		name = name.replaceAll(" ", "_");
		return name+" "+amount+" "+durationType+" "+expenseType+" "+(day+1)+" "+(month+1)+" "+year;
	}
}
