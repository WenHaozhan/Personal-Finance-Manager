import java.util.*; 
import java.io.*;
import javax.swing.*;
import javax.swing.border.*;

import java.awt.*;
import java.awt.event.*;

public class Login{
	//gui
	static private BufferedReader br;
	static private PrintWriter out;
	static private JFrame loginMenu;

	static private JButton login;
	static private JButton signup;
	static private JPanel optionPanel;
	
	//login panel 
	static private JPasswordField loginPasswordField;
	static private JTextField loginUserField;
	static private JButton loginButton;
	
	static private JLabel passwordLabel;
	static private JLabel userLabel;
	
	//signup panel
	static private JPasswordField signupPasswordField;
	static private JTextField signupUserField;
	static private JTextField signupNameField;
	static private JLabel nameLabel;
	static private JButton register;
	static private JButton cancel;
	
	
	//non gui
	static private ArrayList<String> usernames;
	static private ArrayList<String> passwords;
	
	private String username;
	private String password;
	private String name;
	private boolean finishedRunning;
	/**
	 * Initiates the login process
	 */
	public Login() {
		usernames = new ArrayList<>();
		passwords = new ArrayList<>();
		
		username = "";name="";password="";finishedRunning = false;
		
		try {
			br = new BufferedReader(new FileReader("login.txt"));
			// the number of different users is stored as the first line of the file
			// the input file is initialized with 0 as the first line
			int n = Integer.parseInt(br.readLine());
			for (int i = 0; i < n; i++) {
				String s = br.readLine();
				String[] S = s.split(" ");
				usernames.add(S[0]);
				passwords.add(S[1]);
			}
			out = new PrintWriter(new BufferedWriter(new FileWriter("login.txt")));
		} catch (IOException e) {}
		
		/*if(0==1) {
			closeProtocol();
			System.out.println("Login exit");
			System.exit(0);	
		}
		*/
		
		loginMenu = new JFrame("Personal Finance Manager Login");
		loginMenu.setSize(500,400);
		loginMenu.setLocationRelativeTo(null);//sets to center of screen
		//loginMenu.setLayout(new GridLayout(2,1));
		Login l = this;
		loginMenu.addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent windowEvent){
				try {
					l.closeProtocol();
				}catch(IOException e){
					System.out.println("Error when closing login window");
				}
				System.exit(0);
				//Runtime.getRuntime().halt(0);//similar to System.exit(0) but 
				//guaranteed to exit
			}
		});
		//initializing buttons on the first login screen
		login = new JButton("Login");
		login.setActionCommand("Login");
		login.addActionListener(new LoginClickListener());
		login.setAlignmentX(Component.CENTER_ALIGNMENT);
		signup = new JButton("Sign Up");
		signup.setActionCommand("Sign Up");
		signup.addActionListener(new LoginClickListener());
		signup.setAlignmentX(Component.CENTER_ALIGNMENT);
		optionPanel = new JPanel();
		optionPanel.setLayout(new BoxLayout(optionPanel,BoxLayout.Y_AXIS));
		optionPanel.add(Box.createRigidArea(new Dimension(loginMenu.getWidth(),80)));
		optionPanel.add(login);
		optionPanel.add(Box.createRigidArea(new Dimension(loginMenu.getWidth(),10)));
		optionPanel.add(signup);
		loginMenu.add(optionPanel);
		
		
		loginUserField = new JTextField();
		loginPasswordField = new JPasswordField();
		userLabel = new JLabel("Username:");
		userLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
		passwordLabel = new JLabel("Password:");
		Border b = BorderFactory.createLineBorder(Color.BLACK,1);
		passwordLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
		loginUserField.setBorder(b);
		loginPasswordField.setBorder(b);
		loginUserField.setPreferredSize(new Dimension(300,20));
		loginUserField.setMinimumSize(new Dimension(300,20));
		loginUserField.setMaximumSize(new Dimension(300,20));
		loginUserField.setAlignmentX(Component.CENTER_ALIGNMENT);
		
		loginPasswordField.setPreferredSize(new Dimension(300,20));
		loginPasswordField.setMaximumSize(new Dimension(300,20));
		loginPasswordField.setMinimumSize(new Dimension(300,20));
		loginPasswordField.setAlignmentX(Component.CENTER_ALIGNMENT);
		loginButton = new JButton("Login");
		loginButton.setActionCommand("login");
		loginButton.addActionListener(new Submit());
		loginButton.setAlignmentX(Component.CENTER_ALIGNMENT);
		
		loginPasswordField.addKeyListener(new LoginEnterListener());
		
		signupPasswordField = new JPasswordField();
		signupUserField = new JTextField();
		signupNameField = new JTextField();
		signupNameField.setBorder(b);
		signupUserField.setBorder(b);
		signupPasswordField.setBorder(b);
		
		signupPasswordField.setPreferredSize(new Dimension(300,20));
		signupPasswordField.setMaximumSize(new Dimension(300,20));
		signupPasswordField.setMinimumSize(new Dimension(300,20));
		signupPasswordField.setAlignmentX(Component.CENTER_ALIGNMENT);
		
		signupUserField.setPreferredSize(new Dimension(300,20));
		signupUserField.setMaximumSize(new Dimension(300,20));
		signupUserField.setMinimumSize(new Dimension(300,20));
		signupUserField.setAlignmentX(Component.CENTER_ALIGNMENT);
		
		signupNameField.setPreferredSize(new Dimension(300,20));
		signupNameField.setMaximumSize(new Dimension(300,20));
		signupNameField.setMinimumSize(new Dimension(300,20));
		signupNameField.setAlignmentX(Component.CENTER_ALIGNMENT);
		
		nameLabel = new JLabel("Full Name (Space in between): ");
		nameLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
		cancel = new JButton("Cancel");
		cancel.addActionListener(new Cancel());
		register  = new JButton("Register");
		register.setAlignmentX(Component.CENTER_ALIGNMENT);
		cancel.setAlignmentX(Component.CENTER_ALIGNMENT);
		register.addActionListener(new Register());
		signupPasswordField.addKeyListener(new RegisterEnterListener());
		
		loginMenu.setVisible(true);

	}
	
	/*
	public static void main(String [] args) throws IOException{
		Login l = new Login();
		
	}
	*/
	//action listener for login/signup button click
	private class LoginClickListener implements ActionListener{
		public void actionPerformed(ActionEvent e) {
			String s = e.getActionCommand();
			if(s.equals("Login")){
				loginProtocol();
			}else if(s.equals("Sign Up")){
				signupProtocol();
			}
		}
	}
	private class LoginEnterListener implements KeyListener{
		public void keyPressed(KeyEvent e) {
			if(e.getKeyCode()==KeyEvent.VK_ENTER) {
				loginButton.doClick();
			}
		}
		public void keyReleased(KeyEvent e) {
		}
		public void keyTyped(KeyEvent e) {
		}
		
	}
	private class Submit implements ActionListener{
		public void actionPerformed(ActionEvent e) {
			username = loginUserField.getText().trim();
			password = new String(loginPasswordField.getPassword());
			if(!usernames.contains(username)){
				createErrorFrame("Invalid Username");
				return;
			}
			if(!password.equals(passwords.get(usernames.indexOf(username)))) {
				createErrorFrame("Invalid Password");
				return;
			}
			try {
				BufferedReader userFile = 
					new BufferedReader(
					new FileReader("UserFiles\\"+username+".txt"));
				name = userFile.readLine();
			
				userFile.close();
				finishedRunning=true;
				closeProtocol();
				loginMenu.dispose();
			}catch(IOException i) {//user file not found
				try {
					GregorianCalendar c = new GregorianCalendar();
					PrintWriter out = new PrintWriter(
							new BufferedWriter(new FileWriter("UserFiles\\" + username + ".txt")));
					out.println("Unknown");
					name = "Unknown";
					// prints account creation year and month (0-11)
					out.println(c.get(Calendar.YEAR) + " " + c.get(Calendar.MONTH));
					out.println(0.0);// initial monthly income not set by user
					// 0 expense objects initially
					out.println("0");
					out.close();
				} catch (IOException a) {
				}
			}
		}
	}
	//on the signup menu and returns to the starting menu
	private class Cancel implements ActionListener{
		public void actionPerformed(ActionEvent e) {
			clearMenu();
			optionPanel.add(Box.createRigidArea(new Dimension(loginMenu.getWidth(),80)));
			
			optionPanel.add(login);
			optionPanel.add(Box.createRigidArea(new Dimension(loginMenu.getWidth(),10)));
			
			optionPanel.add(signup);
			
			loginMenu.add(optionPanel);
			refreshMenu();
		}
	}
	private class Register implements ActionListener{
		public void actionPerformed(ActionEvent e) {
			name = signupNameField.getText().trim();
			username = signupUserField.getText();
			password = new String(signupPasswordField.getPassword());
			if(usernames.contains(username)) {
				createErrorFrame("Username Taken");
				return;
			}
			if(name.equals("")) {
				createErrorFrame("Invalid Name");
				return;
			}
			if(username.length()==0) {
				createErrorFrame("Invalid Username");
				return;
			}
			else if(username.indexOf(" ")>-1) {
				createErrorFrame("Invalid Password: No spaces allowed");
				return;
			}
			if(password.length()==0) {
				createErrorFrame("Invalid Password");
				return;
			}
			else if(password.indexOf(" ")>-1) {
				createErrorFrame("Invalid Password: No spaces allowed");
				return;
			}
			try {
				GregorianCalendar c = new GregorianCalendar();
				PrintWriter out = new PrintWriter(
						new BufferedWriter(
						new FileWriter("UserFiles\\"+username+".txt")));
				out.println(name);
				//prints account creation year and month (0-11)
				out.println(c.get(Calendar.YEAR) + " " +c.get(Calendar.MONTH));
				out.println(0.0);//initial monthly income not set by user
				
				//0 expense objects initially
				out.println("0");
				out.close();
				usernames.add(username);
				passwords.add(password);
				login.doClick();
			}catch(IOException i) {
				System.out.println("User files creation error");
			}
		}
	}
	private class RegisterEnterListener implements KeyListener{
		public void keyPressed(KeyEvent e) {
			if(e.getKeyCode()==KeyEvent.VK_ENTER) {
				register.doClick();
			}
		}
		public void keyReleased(KeyEvent e) {
		}
		public void keyTyped(KeyEvent e) {
		}
	}
	
	private void loginProtocol() {
		clearMenu();
		
		loginMenu.add(optionPanel);
		optionPanel.add(Box.createRigidArea(new Dimension(loginMenu.getWidth(),40)));
		optionPanel.add(userLabel);
		optionPanel.add(loginUserField);
		optionPanel.add(Box.createRigidArea(new Dimension(loginMenu.getWidth(),40)));
		optionPanel.add(passwordLabel);
		optionPanel.add(loginPasswordField);
		optionPanel.add(Box.createRigidArea(new Dimension(loginMenu.getWidth(),40)));
		optionPanel.add(loginButton);
		
		refreshMenu();
		
	}
	private void signupProtocol() {
		clearMenu();
		
		optionPanel.add(Box.createRigidArea(new Dimension(loginMenu.getWidth(),40)));
		optionPanel.add(nameLabel);
		optionPanel.add(signupNameField);
		optionPanel.add(Box.createRigidArea(new Dimension(loginMenu.getWidth(),40)));
		
		optionPanel.add(userLabel);
		optionPanel.add(signupUserField);
		optionPanel.add(Box.createRigidArea(new Dimension(loginMenu.getWidth(),40)));
		
		optionPanel.add(passwordLabel);
		optionPanel.add(signupPasswordField);
		optionPanel.add(Box.createRigidArea(new Dimension(loginMenu.getWidth(),40)));
		
		optionPanel.add(register);
		optionPanel.add(Box.createRigidArea(new Dimension(loginMenu.getWidth(),10)));
		
		optionPanel.add(cancel);
		
		loginMenu.add(optionPanel);
		refreshMenu();
		
		//loginProtocol();
	}

	private void closeProtocol() throws IOException {
		try {
			out.println(usernames.size());
			for (int i = 0; i < usernames.size(); i++) {
				out.println(usernames.get(i) + " " + passwords.get(i));
			}
			br.close();
			out.close();
			synchronized (this) {
				this.notifyAll();
			}
		} catch (Exception e) {
		}
	}
	
	private void clearMenu(){
		//loginMenu.getContentPane().removeAll();
		optionPanel.removeAll();
		optionPanel.setLayout(new BoxLayout(optionPanel,BoxLayout.Y_AXIS));
		optionPanel.revalidate();
	}
	private void refreshMenu() {
		loginMenu.revalidate();
		loginMenu.repaint();
	}
	private void createErrorFrame(String text) {
		JFrame warning = new JFrame("Error");
		warning.add(new JLabel(text,SwingConstants.CENTER));
		warning.setSize(50,100);
		warning.setLocationRelativeTo(null);
		warning.setVisible(true);
	}
	/**
	 * 
	 * @return The username string of the logged-in user
	 */
	public String getUsername(){
		return username;
	}
	/**
	 * 
	 * @return The name string of the logged-in user
	 */
	public String getName() {
		return name;
	}
	/**
	 * 
	 * @return true if the user has successfully logged in, false login was prematurely terminated
	 */
	public boolean finished() {
		return finishedRunning;
	}
	
}
