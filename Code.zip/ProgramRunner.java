import java.io.*;

import javax.swing.*;

import java.awt.*;
import java.awt.event.*;

public class ProgramRunner {

	static JFrame mainFrame = new JFrame("Personal Financial Manager");

	static JPanel topbar = new JPanel();
	static JPanel controlbar = new JPanel();
	static JButton calendarButton = new JButton("Calendar");
	static JButton search = new JButton("Search");
	static JButton summary = new JButton("Summary");
	static JButton edit = new JButton("Edit");
	static JButton current;// keeps track of current button
	static JButton leftArrow = new JButton("<");
	static JLabel dateLabel;
	static JButton rightArrow =new JButton(">");
	
	
	static CalendarGUI c;
	static User u;

	public static void main(String[] args) throws IOException, InterruptedException {
		Login l = new Login();

		// wait until login gui finishes running
		
		synchronized(l) {
			l.wait();
		} 
		if(!l.finished()) {
			System.exit(0);
		}
		
		String s1 = l.getName();
		String s2 = l.getUsername();
		 
		u = new User(s1,s2);
		c = new CalendarGUI();
		
		/*
		u.addExpense("Rent",1500,2,1,16,1,2021);
		for(int i =0;i<11;i++) {
			u.addExpense("Internet",80-i,2,2,16,1,2021);
		}*/
		
		mainFrame.setSize(1000, 600);
		mainFrame.setLocationRelativeTo(null);
		// properly ends the program when closed
		mainFrame.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent windowEvent) {
				try {
					u.closeProtocol(); 
				}catch(IOException e) {
					System.out.println("User File error"); 
				}
				 
				System.exit(0);
			}
		});
		mainFrame.setLayout(null);

		
		
		calendarButton.setActionCommand("Calendar");
		edit.setActionCommand("Edit");
		
		calendarButton.addActionListener(new TopbarListener());
		edit.addActionListener(new TopbarListener());
		summary.addActionListener(new TopbarListener());
		search.addActionListener(new TopbarListener());
		
		topbar.setBounds(0, 0, 1000, 50);
		topbar.add(calendarButton);
		topbar.add(summary);
		topbar.add(search);
		topbar.add(edit);
		
		leftArrow.addActionListener(new PreviousMonth());
		rightArrow.addActionListener(new NextMonth());
		
		controlbar.setBounds(0,50,1000,50);
		dateLabel = new JLabel(c.getMonth()+" "+c.getYear());
		controlbar.add(leftArrow);
		controlbar.add(dateLabel);
		controlbar.add(rightArrow);
		
		
		
		
		
		//Calendar is the default view
		calendarButton.doClick();
		current = calendarButton;
		
		mainFrame.setVisible(true);
	}
	
	//refreshes the frame appropriately when a button in topbar is clicked
	static public class TopbarListener implements ActionListener{
		public void actionPerformed(ActionEvent e) {
			String s = e.getActionCommand();
			
			//dont do anything is the button clicked is the current displayed item
			if(current==e.getSource()) {
				return;
			}
			mainFrame.getContentPane().removeAll();
			mainFrame.setLayout(null);
			mainFrame.add(topbar);
			if(s.equals("Calendar")) {
				mainFrame.add(controlbar);
				mainFrame.add(c.getPanel(
						u.returnMonthlyExpenses(c.getMonthInt(), c.getDaysInMonth())));
			}else if(s.equals("Search")) {
				mainFrame.add(u.getSearchPanel());
			}else if(s.equals("Edit")) {
				mainFrame.add(u.getEditMenu());
			}else if(s.equals("Summary")) {
				mainFrame.add(u.getSummaryPanel());
			}
			current = (JButton) e.getSource();
			
			mainFrame.revalidate();
			mainFrame.repaint();
		}
	}
	static public class PreviousMonth implements ActionListener{
		public void actionPerformed(ActionEvent e) {
			//false if currently viewed month and year are same as user
			//creation month and year
			if(u.afterCreationDate(c.getYear(), c.getMonthInt())) {
				c.decreaseMonth();
				c.getPanel(u.returnMonthlyExpenses(c.getMonthInt(), c.getDaysInMonth()));
				refreshControlbar();
				mainFrame.revalidate();
				mainFrame.repaint();
			}else {
				JFrame error = new JFrame("Error");
				error.setSize(250,200);
				error.setLocationRelativeTo(null);
				error.add(new Label("Can not go to previous month"));
				error.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
				error.setVisible(true);
			}
		}
	}
	/**
	 * Refreshed the calendar control bar label when currently viewed month is changed
	 */
	public static void refreshControlbar() {
		controlbar.removeAll();
		controlbar.add(leftArrow);
		dateLabel = new JLabel(c.getMonth()+" "+c.getYear());
		controlbar.add(dateLabel);
		controlbar.add(rightArrow);
	}
	static public class NextMonth implements ActionListener{
		public void actionPerformed(ActionEvent e) {
			c.increaseMonth();
			c.getPanel(u.returnMonthlyExpenses(c.getMonthInt(), c.getDaysInMonth()));
			refreshControlbar();
			mainFrame.revalidate();
			mainFrame.repaint();
		}
	}
}
