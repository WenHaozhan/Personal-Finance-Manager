import java.util.*;


import javax.swing.*;


import java.awt.*;
import java.awt.event.*;

public class Tester {
	//not a relevant class used in the program
static JFrame mainFrame = new JFrame("Personal Financial Manager");
	
	static JPanel topbar = new JPanel();
	static JButton calendarButton = new JButton("Calendar");
	static JButton search = new JButton("Search");
	static JButton summary = new JButton("Summary");
	static JButton edit = new JButton("Edit");
	static JPanel calendar = new JPanel();
	public static void main(String[] args) {
		mainFrame.setSize(1000,600);
		mainFrame.setLocationRelativeTo(null);
		
		//properly ends the program when closed
		//mainFrame.setLayout();
		topbar.setLayout(new GridLayout(1,4));
		
		topbar.add(calendarButton);topbar.add(search);topbar.add(summary);topbar.add(edit);
		calendar.setComponentOrientation(ComponentOrientation.LEFT_TO_RIGHT);
		calendar.setLayout(new GridLayout(7,7));
		mainFrame.setResizable(false);
		topbar.setMaximumSize(new Dimension(1000,50));
		
		String [] days = {"Sun","Mon","Tue","Wed","Thu","Fri","Sat"};
		for(int i = 0;i<days.length;i++) {
			calendar.add(new JLabel(days[i]));
		}
		
		System.out.println(calendar.getComponentOrientation().isHorizontal());
		mainFrame.add(topbar);
		calendar.setMaximumSize(new Dimension(1000,500));
		mainFrame.add(calendar);
		
		GregorianCalendar c = new GregorianCalendar();
		
		System.out.println(c.get(Calendar.DAY_OF_MONTH));
		mainFrame.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent windowEvent){
				System.exit(0);
			}
		});
		mainFrame.setVisible(true);
		
	}

}
