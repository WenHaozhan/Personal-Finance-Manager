import java.io.*;
import java.util.*;
import javax.swing.*;


import java.awt.*;
import java.awt.event.*;

public class User {
	private static BufferedReader br;
	private static PrintWriter out;
	private static JPanel editMenu = new JPanel();
	private static JTextField incomeSetter;
	private static JLabel incomeLabel = new JLabel("Monthly Income: $");
	private static JButton setButton = new JButton("Set");
	private static JButton addExpense = new JButton("Add Expense");
	private static JPanel summaryPanel = new JPanel();
	private static JPanel searchPanel = new JPanel();
	private static JPanel searchedExpenses = new JPanel(new GridLayout(0,1));
	private static JScrollPane searchScroll = new JScrollPane(searchedExpenses, 
			ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS,
			ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
	
	
	private String name;
	private String username;
	private double monthlyIncome;

	// month and year the account was created
	// serves as index zero for the expenses
	// for simplification, the user can not edit or view expenses
	// before the creation date
	private int creationYear;
	private int creationMonth;

	private ArrayList<Expense> expenses;
	private ArrayList<Expense> searched;
	
	/**
	 * Creates a User object with a creation year and creation month the date that
	 * the constructor is called, list of expenses is empty
	 * Used for testing purposes
	 */
	public User() {
		GregorianCalendar c= new GregorianCalendar();
		creationYear = c.get(Calendar.YEAR);
		creationMonth = c.get(Calendar.MONTH);
		expenses = new ArrayList<>();
		searched = new ArrayList<>();
	}
	/**
	 * 
	 * @param n string of the user's name
	 * @param u string of the user's username
	 * @throws IOException when the user's file is not found
	 */
	//The Login class handles the IOException where the User's .txt file is not found
	public User(String n, String u) throws IOException {
		name = n;
		username = u;

		br = new BufferedReader(new FileReader("UserFiles\\" + username + ".txt"));

		br.readLine();// first line is name
		String s = br.readLine();// creation date
		String[] S = s.split(" ");
		creationYear = Integer.parseInt(S[0]);
		creationMonth = Integer.parseInt(S[1]);

		monthlyIncome = Double.parseDouble(br.readLine());
		expenses = new ArrayList<>();
		searched = new ArrayList<>();

		int num = Integer.parseInt(br.readLine());
		for (int i = 0; i < num; i++) {
			s = br.readLine();// reads string representation of expense
			S = s.split(" ");
			expenses.add(new Expense(S[0], Double.parseDouble(S[1]), Integer.parseInt(S[2]), Integer.parseInt(S[3]),
					Integer.parseInt(S[4]), Integer.parseInt(S[5]), Integer.parseInt(S[6])));
		}
		br.close();

	}

	//testing purposes
	public static void main(String[] args) {
		JFrame main = new JFrame();
		main.setSize(1000, 600);
		main.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		User u = new User();
		u.expenses.add(new Expense("Rent", 1500, 2, 1, 16, 0,2021));
		
		for (int i = 0; i < 11; i++) {
			u.expenses.add(new Expense("Internet", 80-i, 2, 2, 16, 0,2021));
		}
		
		/*
		for(int i = 'z';i>='a';i--) {
			u.expenses.add(new Expense((char)i+"", 1500, 2, 1, 16, 0,2021));
		*/
		u.setIncome(5000);
		u.sortExpensesByName();
		u.sortExpensesByAmount();
		main.add(u.getEditMenu());
		
		main.setVisible(true);
	}
	
	/**
	 * 
	 * @param month integer from 0-11 representing January to December
	 * @param daysInMonth the number of days in specified month
	 * @return an ArrayList is size daysInMonth where each element is another ArrayList with the expenses due that day 
	 */
	// month 0-11
	public ArrayList<ArrayList<Expense>> returnMonthlyExpenses(int month, int daysInMonth){
		ArrayList<ArrayList<Expense>> temp = new ArrayList<>();
		for(int i = 0;i<daysInMonth;i++) {
			temp.add(new ArrayList<>());
		}
		for(Expense i: expenses){
			if(i.getFrequencyInt()==2){
				temp.get(i.getDay()).add(i);
			}
			if(i.getFrequencyInt()==1) {
				if(i.getMonth()==month) {
					temp.get(i.getDay()).add(i);
				}
			}
			if(i.getFrequencyInt()==3) {
				if(i.getMonth()==month) {
					temp.get(i.getDay()).add(i);
				}
			}
		}
		
		return temp;
	}
	
	/**
	 * sets the user's monthly income
	 * @param d the users monthly income
	 */
	public void setIncome(double d) {
		monthlyIncome = d;
	}
	/**
	 * 
	 * @return the user's monthly income
	 */
	public double getIncome() {
		return monthlyIncome;
	}
	/**
	 * Checks whether the Calendar's month increment goes before the User's account creation date
	 * @param year is the wanted year
	 * @param month is wanted month of year
	 * @return true if date, not including day, is equal to or after account creation date, false otherwise
	 */
	public boolean afterCreationDate(int year, int month) {
		if(year<creationYear) return false;
		if(year==creationYear&&month<=creationMonth)return false;
		return true;
	}
	
	/**
	 * 
	 * @return JPanel containing the user interface elements to edit expenses, sort expenses, set income
	 */
	public JPanel getEditMenu() {
		editMenu.removeAll();
		editMenu.setLayout(null);
		editMenu.setBounds(0, 50, 1000, 500);

		incomeLabel.setBounds(5, 0, 120, 30);

		editMenu.add(incomeLabel);
		
		
		
		String text = "";

		// if the user has not set monthly income i.e. new user, set text as
		if (getIncome() == 0) {
			text = "Enter monthly income";
		} else {
			text += String.format("%.2f", getIncome());
		}
		incomeSetter = new JTextField(text, 20);

		// GUI is hardcoded
		incomeSetter.setBounds(incomeLabel.getWidth(), 5, 200, incomeLabel.getHeight() - 5);
		incomeSetter.addMouseListener(new IncomeFieldClick());
		incomeSetter.addKeyListener(new IncomeFieldEnter());

		setButton.setBounds(incomeSetter.getX() + incomeSetter.getWidth() + 10, 0, 80, incomeLabel.getHeight());
		if(setButton.getActionListeners().length==1) {
			setButton.removeActionListener(setButton.getActionListeners()[0]);
		}
		
		setButton.addActionListener(new SetButtonClick());
		
		JLabel sortBy = new JLabel("Sort by: ");
		sortBy.setBounds(setButton.getX() + setButton.getWidth()+10,0,
				sortBy.getPreferredSize().width+5,setButton.getHeight());
		
		editMenu.add(sortBy);
		
		ButtonGroup sortOptions = new ButtonGroup();
		
		JRadioButton name = new JRadioButton("Name");
		JRadioButton amount = new JRadioButton("Amount");
		sortOptions.add(name);sortOptions.add(amount);
		name.setBounds(sortBy.getX()+sortBy.getWidth()+5,0,name.getPreferredSize().width+5
				,sortBy.getHeight());
		amount.setBounds(name.getX()+name.getWidth()+5,0,amount.getPreferredSize().width+5
				,sortBy.getHeight());
		
		
		JButton sort = new JButton("Sort");
		sort.setBounds(amount.getX()+amount.getWidth()+5,0,sort.getPreferredSize().width
				,sortBy.getHeight());
		sort.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String s = "";
				for (Enumeration<AbstractButton> i = sortOptions.getElements(); i.hasMoreElements();) {
					AbstractButton button = i.nextElement();
					if (button.isSelected()) {
						s = (button).getActionCommand();
					}
				}
				if(s.equals("")) {
					createErrorFrame("Please select a sort option");
					return;
				}
				if(s.equals("Name")) {
					sortExpensesByName();
				}
				if(s.equals("Amount")) {
					sortExpensesByAmount();
				}
				getEditMenu();
				SwingUtilities.getRoot(editMenu).revalidate();
				SwingUtilities.getRoot(editMenu).repaint();
			}
		});
		
		editMenu.add(name);editMenu.add(amount);editMenu.add(sort);
		
		
		addExpense.setBounds(editMenu.getWidth() - 120 - 14, 0, 120, incomeLabel.getHeight());
		if(addExpense.getActionListeners().length==1) {
			addExpense.removeActionListener(addExpense.getActionListeners()[0]);
		}
		addExpense.addActionListener(new AddExpense());

		editMenu.add(incomeSetter);
		editMenu.add(setButton);
		editMenu.add(addExpense);
		
		// list headers like ExpenseName, amount, frequency
		JPanel expenseListLabels = new JPanel();
		expenseListLabels.setLayout(null);
		JLabel expenseNameLabel = new JLabel("Expense Name");
		JLabel amountLabel = new JLabel("Amount ($)");
		JLabel frequencyLabel = new JLabel("Frequency");

		expenseListLabels.setBounds(0, incomeLabel.getHeight() + 10, 1000, 30);
		expenseNameLabel.setBounds(5, 0, expenseNameLabel.getPreferredSize().width + 5, 30);
		amountLabel.setBounds(500, 0, 80, 30);
		frequencyLabel.setBounds(700, 0, 80, 30);

		expenseListLabels.add(expenseNameLabel);
		expenseListLabels.add(amountLabel);
		expenseListLabels.add(frequencyLabel);

		editMenu.add(expenseListLabels);

		JPanel expenseList = new JPanel();

		expenseList.setSize(editMenu.getWidth(),
				editMenu.getHeight() - expenseListLabels.getY() - expenseListLabels.getHeight());
		expenseList.setLayout(new GridLayout(0, 1));

		JScrollPane expenseListScroll = new JScrollPane(expenseList, ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS,
				ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		expenseListScroll.setLocation(0, expenseListLabels.getY() + expenseListLabels.getHeight() + 5);
		expenseListScroll.setSize(
				editMenu.getWidth() - expenseListScroll.getVerticalScrollBar().getPreferredSize().width,
				editMenu.getHeight() - expenseListScroll.getY() - expenseListScroll.getHeight());

		for (int i = 0; i < expenses.size(); i++) {
			JPanel temp = new JPanel();
			temp.setLayout(null);
			temp.setPreferredSize(new Dimension(
					expenseListScroll.getWidth() - expenseListScroll.getVerticalScrollBar().getPreferredSize().width,
					50));

			JButton delete = new JButton("Delete");
			delete.setActionCommand("" + i);
			delete.addActionListener(new DeleteExpense());

			String s = expenses.get(i).getName();
			if (s.length() > 20) {
				s = s.substring(0, 18) + "...";
			}
			JLabel expenseName = new JLabel(s);
			expenseName.setBounds(5, 0, expenseName.getPreferredSize().width + 10, 50);

			temp.add(expenseName);
			JLabel expenseAmount = new JLabel(String.format("%.2f", expenses.get(i).getAmount()));
			expenseAmount.setBounds(500, 0, expenseAmount.getPreferredSize().width, 50);
			temp.add(expenseAmount);
			JLabel expenseFreq = new JLabel(expenses.get(i).getFrequency());
			expenseFreq.setBounds(700, 0, expenseFreq.getPreferredSize().width + 10, 50);
			delete.setBounds(temp.getPreferredSize().width - delete.getPreferredSize().width - 10, 0,
					delete.getPreferredSize().width + 10, 50);

			temp.add(expenseFreq);
			temp.add(delete);
			expenseList.add(temp);
		}

		editMenu.add(expenseListScroll);

		return editMenu;
	}
	
	/**
	 * 
	 * @return JPanel containing the user interface elements of the monthly budget summary of current month
	 */
	public JPanel getSummaryPanel() {
		summaryPanel.removeAll();
		summaryPanel.setSize(1000,450);
		summaryPanel.setLocation(0,50);
		//income of 0 means that it was not set by the user
		if(monthlyIncome==0) {
			summaryPanel.add(new JLabel("Please Set a Value For Your Monthly Income in the Edit Menu",
					JLabel.CENTER ));
			return summaryPanel;
		}
		
		//Only calculates the monthly budget for current month, rather than
		//the month that the user is viewing
		summaryPanel.setLayout(new BoxLayout(summaryPanel,BoxLayout.Y_AXIS));
		GregorianCalendar c = new GregorianCalendar();
		int currentMonth = c.get(Calendar.MONTH);
		int currentYear = c.get(Calendar.YEAR);
		
		JLabel title = new JLabel("Budget Summary For The Month "+
		CalendarGUI.MONTH[currentMonth]+" "+currentYear,JLabel.CENTER);
		title.setAlignmentX(JLabel.CENTER_ALIGNMENT);
		title.setFont(new Font("Dialog",Font.BOLD,24));
		summaryPanel.add(title);
		
		double oneTimeExpenses=0,recurringExpenses = 0;
		for(Expense i : expenses) {
			if(i.isRecurring()) {
				if(i.getFrequencyInt()==2) {
					recurringExpenses+=i.getAmount();
				}else if(i.getFrequencyInt()==3&&i.getMonth()==currentMonth) {
					recurringExpenses+=i.getAmount();
				}
			}else {
				if(currentMonth==i.getMonth()&&currentYear==i.getYear()) {
					oneTimeExpenses+=i.getAmount();
				}
			}
		}
		
		JPanel oneTime = new JPanel();
		JPanel recurring = new JPanel();
		oneTime.setLayout(null);recurring.setLayout(null);
		oneTime.setPreferredSize(new Dimension(6,10));
		
		JLabel temp1 = new JLabel("This month's one time expenses:");
		JLabel temp2 = new JLabel(String.format("$%.2f",oneTimeExpenses));
		temp1.setBounds(20, 0, temp1.getPreferredSize().width+10, temp1.getPreferredSize().height);
		temp2.setBounds(1000-temp2.getPreferredSize().width-50,
				0,temp2.getPreferredSize().width+5,temp2.getPreferredSize().height);
		oneTime.add(temp1);oneTime.add(temp2);
		
		JLabel temp3 = new JLabel("This month's recurring expenses:");
		JLabel temp4 = new JLabel(String.format("$%.2f",recurringExpenses));
		temp3.setBounds(20, 0, temp3.getPreferredSize().width+10, temp3.getPreferredSize().height);
		temp4.setBounds(1000-temp4.getPreferredSize().width-50,
				0,temp4.getPreferredSize().width+5,temp4.getPreferredSize().height);
		recurring.add(temp3);recurring.add(temp4);
		
		JPanel total = new JPanel();total.setLayout(null);
		JLabel temp5 = new JLabel("Total:");
		double totalExpenses = oneTimeExpenses+recurringExpenses;
		JLabel temp6 = new JLabel(String.format("$%.2f",totalExpenses));
		temp5.setBounds(20, 0, temp5.getPreferredSize().width+10, temp5.getPreferredSize().height);
		temp6.setBounds(1000-temp6.getPreferredSize().width-50,
				0,temp6.getPreferredSize().width+5,temp6.getPreferredSize().height);
		total.add(temp5);total.add(temp6);
		
		JPanel budget = new JPanel();budget.setLayout(null);
		JLabel temp7 = new JLabel("This month's net budget");
		double netBudget = monthlyIncome-totalExpenses;
		JLabel temp8 = new JLabel(String.format("$%.2f",netBudget));
		if(netBudget<0) {
			temp8.setForeground(Color.RED);
		}else {
			temp8.setForeground(Color.green);
			
		}
		temp7.setBounds(20, 0, temp7.getPreferredSize().width+10, temp7.getPreferredSize().height);
		temp8.setBounds(1000-temp8.getPreferredSize().width-50,
				0,temp8.getPreferredSize().width+5,temp8.getPreferredSize().height);
		budget.add(temp7);budget.add(temp8);
		
		summaryPanel.add(oneTime);summaryPanel.add(recurring);
		summaryPanel.add(total);summaryPanel.add(budget);


		
		
		return summaryPanel;
	}
	
	/**
	 * 
	 * @return JPanel containing the user interface to search for expenses
	 */
	public JPanel getSearchPanel() {
		searchPanel.removeAll();
		searchPanel.setLayout(new BoxLayout(searchPanel, BoxLayout.Y_AXIS));
		searchPanel.setBounds(0,50,985,500);
		
		JPanel searchBar = new JPanel();
		searchBar.setMaximumSize(new Dimension(1000,40));
		searchBar.add(new JLabel("Search By: "));
		ButtonGroup searchOptions = new ButtonGroup();
		String [] searchOptionStrings = {"Name","Amount Range","Frequency"};
		JPanel optionSpecifics = new JPanel();
		optionSpecifics.setMaximumSize(new Dimension(1000,40));
		optionSpecifics.setMinimumSize(new Dimension(1000,40));
		optionSpecifics.setPreferredSize(new Dimension(1000,40));
		
		JPanel searchedExpenseLabels = new JPanel();
		searchedExpenseLabels.setLayout(null);
		JLabel expenseNameLabel = new JLabel("Expense Name");
		JLabel amountLabel = new JLabel("Amount ($)");
		JLabel frequencyLabel = new JLabel("Frequency");
		searchedExpenseLabels.setLocation(0,optionSpecifics.getY()
				+optionSpecifics.getHeight());
		searchedExpenseLabels.setMaximumSize(new Dimension(1000,40));
		searchedExpenseLabels.setPreferredSize(new Dimension(1000,40));
		
		expenseNameLabel.setBounds(5, 0, expenseNameLabel.getPreferredSize().width + 5, 30);
		amountLabel.setBounds(500, 0, 80, 30);
		frequencyLabel.setBounds(700, 0, 80, 30);

		searchedExpenseLabels.add(expenseNameLabel);
		searchedExpenseLabels.add(amountLabel);
		searchedExpenseLabels.add(frequencyLabel);

		
		
		for(int i = 0;i<searchOptionStrings.length;i++) {
			JRadioButton temp = new JRadioButton(searchOptionStrings[i]);
			searchOptions.add(temp);
			temp.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					String s = e.getActionCommand();
					optionSpecifics.removeAll();
					if(s.equals(searchOptionStrings[0])) {
						optionSpecifics.add(new JLabel("Name: "));
						JTextField name = new JTextField(20);
						optionSpecifics.add(name);
						JButton search = new JButton("Search");
						search.addActionListener(new ActionListener() {
							public void actionPerformed(ActionEvent a) {
								searched.clear();
								String searchKey = name.getText();
								for(Expense expense:expenses) {
									if((expense.getName()).indexOf(searchKey)>-1) {
										searched.add(expense);
									}
								}
								refreshSearchScroll();
							}
						});
						optionSpecifics.add(search);
					}
					if(s.equals(searchOptionStrings[1])) {
						optionSpecifics.add(new JLabel("Amount from: "));
						JTextField amountFrom = new JTextField(10);
						optionSpecifics.add(amountFrom);
						optionSpecifics.add(new JLabel("Amount to:"));
						JTextField amountTo = new JTextField(10);
						optionSpecifics.add(amountTo);
						JButton search = new JButton("Search");
						search.addActionListener(new ActionListener() {
							public void actionPerformed(ActionEvent a) {
								try {
									double from = Double.parseDouble(amountFrom.getText());
									double to = Double.parseDouble(amountTo.getText());
									searched.clear();
									for(Expense expense:expenses) {
										if(from<=expense.getAmount()&&expense.getAmount()<=to) {
											searched.add(expense);
										}
									}
									refreshSearchScroll();
								}catch(NumberFormatException n) {
									createErrorFrame("Please Enter a Number in the Fields");
								}
							}
						});
						optionSpecifics.add(search);
					}
					if(s.equals(searchOptionStrings[2])){
						ButtonGroup freqType = new ButtonGroup();
						JRadioButton onetime = new JRadioButton("One Time");
						onetime.setActionCommand("1");onetime.addActionListener(new ActionListener() {
							public void actionPerformed(ActionEvent a) {
								searched.clear();
								int type = Integer.parseInt(a.getActionCommand());
								for(Expense expense:expenses) {
									if(expense.getFrequencyInt()==type) {
										searched.add(expense);
									}
								}
								refreshSearchScroll();
								
							}
						});
						JRadioButton monthly = new JRadioButton("Monthly");
						monthly.setActionCommand("2");monthly.addActionListener(onetime.getActionListeners()[0]);
						JRadioButton yearly = new JRadioButton("Yearly");
						yearly.setActionCommand("3");yearly.addActionListener(onetime.getActionListeners()[0]);
						freqType.add(onetime);freqType.add(monthly);freqType.add(yearly);
						optionSpecifics.add(onetime);optionSpecifics.add(monthly);
						optionSpecifics.add(yearly);
					}

					SwingUtilities.getWindowAncestor(searchPanel).revalidate();
					SwingUtilities.getWindowAncestor(searchPanel).repaint();
				}
			});
			searchBar.add(temp);
		}
		
		searchPanel.add(searchBar);
		searchPanel.add(optionSpecifics);
		searchPanel.add(searchedExpenseLabels);

				
		searchPanel.add(searchScroll);
		return searchPanel;
	}
	
	private void refreshSearchScroll(){
		searchedExpenses.removeAll();
		for(int i = 0;i<searched.size();i++) {
			JPanel temp = new JPanel();
			temp.setLayout(null);
			temp.setPreferredSize(new Dimension(
					searchScroll.getWidth() - searchScroll.getVerticalScrollBar().getPreferredSize().width,
					50));
			
			JButton delete = new JButton("Delete");
			delete.setActionCommand("" + i);
			delete.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					JFrame confirm = new JFrame("Confirm");
					confirm.setSize(250, 150);

					confirm.setLocationRelativeTo(null);
					confirm.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
					confirm.setLayout(null);
					JLabel confirmLabel = new JLabel("Are you sure?", SwingConstants.CENTER);
					confirmLabel.setBounds(confirm.getWidth() / 2 - confirmLabel.getPreferredSize().width / 2 - 5, 10,
							confirmLabel.getPreferredSize().width + 10, confirmLabel.getPreferredSize().height);

					confirm.add(confirmLabel);
					JButton yes = new JButton("Yes");
					yes.setBounds(50, 45, 70, 30);
					JButton no = new JButton("No");
					no.setBounds(130, 45, 70, 30);

					yes.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent a) {
							int index = Integer.parseInt(e.getActionCommand());
							//removes the searched object from both lists
							expenses.remove(searched.remove(index));
							searchedExpenses.remove(index);
							for(int j = index;j<searched.size();j++) {
								((JButton)((JPanel)searchedExpenses.getComponent(j)).getComponent(3)).setActionCommand(""+(j));
							}
							SwingUtilities.getWindowAncestor(searchedExpenses).revalidate();
							SwingUtilities.getWindowAncestor(searchedExpenses).repaint();
							confirm.dispose();
						}
					});
					no.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent a) {
							confirm.dispose();
						}
					});

					confirm.add(yes);
					confirm.add(no);
					confirm.setVisible(true);
				}
			});

			String s = searched.get(i).getName();
			if (s.length() > 20) {
				s = s.substring(0, 18) + "...";
			}
			JLabel expenseName = new JLabel(s);
			expenseName.setBounds(5, 0, expenseName.getPreferredSize().width + 10, 50);

			temp.add(expenseName);
			JLabel expenseAmount = new JLabel(String.format("%.2f", searched.get(i).getAmount()));
			expenseAmount.setBounds(500, 0, expenseAmount.getPreferredSize().width, 50);
			temp.add(expenseAmount);
			JLabel expenseFreq = new JLabel(searched.get(i).getFrequency());
			expenseFreq.setBounds(700, 0, expenseFreq.getPreferredSize().width + 10, 50);
			delete.setBounds(temp.getPreferredSize().width - delete.getPreferredSize().width - 10, 0,
					delete.getPreferredSize().width + 10, 50);

			temp.add(expenseFreq);
			temp.add(delete);
			
			searchedExpenses.add(temp);
		}
		SwingUtilities.getWindowAncestor(searchedExpenses).revalidate();
		SwingUtilities.getWindowAncestor(searchedExpenses).repaint();

	}
	
	/**
	 * Outputs the user's information in a .txt files with the user's username as the file name
	 * @throws IOException when file can not be created
	 */
	public void closeProtocol() throws IOException{
		out = new PrintWriter(new BufferedWriter(new FileWriter("UserFiles\\" + username + ".txt")));
		out.println(name);
		out.println(creationYear+" "+creationMonth);
		out.println(monthlyIncome);
		out.println(expenses.size());// num days in month
		for (Expense i : expenses) {
			out.println(i);
		}
		out.close();
		
	}

	// makes the user confirm that they want to change their monthly income

	// listeners
	private class IncomeFieldClick extends MouseAdapter {
		public void mouseClicked(MouseEvent e) {
			incomeSetter.setText("");
		}
	}

	private class IncomeFieldEnter extends KeyAdapter {
		public void keyPressed(KeyEvent e) {
			if (e.getKeyCode() == KeyEvent.VK_ENTER) {
				setButton.doClick();
			}
		}
	}

	private class SetButtonClick implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			String s = incomeSetter.getText();
			try {
				double d = Double.parseDouble(s);
				JFrame confirm = new JFrame("Confirm");
				confirm.setSize(150, 100);
				confirm.setLocationRelativeTo(null);
				confirm.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
				confirm.setLayout(new FlowLayout());
				JLabel confirmLabel = new JLabel("Are you sure?",  SwingConstants.CENTER);
				confirmLabel.setPreferredSize(new Dimension(150, 20));
				confirmLabel.setMinimumSize(new Dimension(150, 20));
				confirm.add(confirmLabel);

				JButton yes = new JButton("Yes");
				yes.setActionCommand("Yes");
				JButton no = new JButton("No");
				no.setActionCommand("No");
				yes.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						String s = e.getActionCommand();
						if (s.equals("Yes")) {
							monthlyIncome = d;
						}
						// closes window when either button is chosen
						((JFrame) SwingUtilities.getWindowAncestor((JButton) e.getSource())).dispose();
					}
				});
				no.addActionListener(yes.getActionListeners()[0]);

				confirm.add(yes);
				confirm.add(no);
				confirm.setVisible(true);
			} catch (NumberFormatException n) {
				JFrame warning = new JFrame("Error");
				warning.add(new JLabel("Please enter a number", SwingConstants.CENTER));
				warning.setSize(150, 100);
				warning.setLocationRelativeTo(null);
				warning.setVisible(true);
			}
		}

	}


	private class DeleteExpense implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			JFrame confirm = new JFrame("Confirm");
			confirm.setSize(250, 150);

			confirm.setLocationRelativeTo(null);
			confirm.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
			confirm.setLayout(null);
			JLabel confirmLabel = new JLabel("Are you sure?", SwingConstants.CENTER);
			confirmLabel.setBounds(confirm.getWidth() / 2 - confirmLabel.getPreferredSize().width / 2 - 5, 10,
					confirmLabel.getPreferredSize().width + 10, confirmLabel.getPreferredSize().height);

			confirm.add(confirmLabel);
			JButton yes = new JButton("Yes");
			yes.setBounds(50, 45, 70, 30);
			JButton no = new JButton("No");
			no.setBounds(130, 45, 70, 30);

			yes.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent a) {
					int i = Integer.parseInt(e.getActionCommand());
					expenses.remove(i);
					getEditMenu();
					((JFrame) (SwingUtilities.getRoot(editMenu))).revalidate();
					((JFrame) (SwingUtilities.getRoot(editMenu))).repaint();

					confirm.dispose();
				}
			});
			no.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent a) {
					confirm.dispose();
				}
			});

			confirm.add(yes);
			confirm.add(no);
			confirm.setVisible(true);
		}
	}

	private class AddExpense implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			JFrame addExpense = new JFrame("Add Expense");
			addExpense.setSize(500, 250);
			addExpense.setLocationRelativeTo(null);
			addExpense.setLayout(null);
			addExpense.setResizable(false);

			JLabel expenseName = new JLabel("Expense Name: ");
			expenseName.setBounds(5, 5, 5 + expenseName.getPreferredSize().width + 5,
					expenseName.getPreferredSize().height);
			JTextField nameField = new JTextField(25);
			nameField.setBounds(5 + expenseName.getWidth() + 5, 5, nameField.getPreferredSize().width,
					nameField.getPreferredSize().height);

			JLabel expenseAmount = new JLabel("Amount: $");
			expenseAmount.setBounds(5, expenseName.getHeight() + 10, expenseAmount.getPreferredSize().width + 10,
					expenseAmount.getPreferredSize().height);

			JTextField amountField = new JTextField(20);
			amountField.setBounds(5 + expenseAmount.getWidth() + 5, expenseName.getHeight() + 10,
					amountField.getPreferredSize().width, amountField.getPreferredSize().height);

			addExpense.add(expenseName);
			addExpense.add(nameField);
			addExpense.add(expenseAmount);
			addExpense.add(amountField);

			// frequency of expense: 1 time, monthly, yearly
			JLabel freqLabel = new JLabel("Frequency: ");
			freqLabel.setBounds(5, expenseAmount.getY() + expenseAmount.getHeight() + 5,
					freqLabel.getPreferredSize().width + 10, freqLabel.getPreferredSize().height);

			ButtonGroup freq = new ButtonGroup();
			JRadioButton onetime = new JRadioButton("One time");
			onetime.setBounds(freqLabel.getWidth() + 5 + 5, freqLabel.getY(), onetime.getPreferredSize().width + 10,
					onetime.getPreferredSize().height);
			onetime.setActionCommand("1");
			JRadioButton monthly = new JRadioButton("Monthly");
			monthly.setBounds(onetime.getX() + onetime.getWidth() + 5, freqLabel.getY(),
					monthly.getPreferredSize().width + 10, monthly.getPreferredSize().height);
			monthly.setActionCommand("2");
			JRadioButton yearly = new JRadioButton("Yearly");
			yearly.setBounds(monthly.getX() + monthly.getWidth() + 5, freqLabel.getY(),
					yearly.getPreferredSize().width + 10, yearly.getPreferredSize().height);
			yearly.setActionCommand("3");
			freq.add(onetime);
			freq.add(monthly);
			freq.add(yearly);

			addExpense.add(freqLabel);
			addExpense.add(onetime);
			addExpense.add(monthly);
			addExpense.add(yearly);

			// type of expense ie rent, utilities, internet etc
			JLabel t = new JLabel("Type: ");
			t.setBounds(5, freqLabel.getY() + freqLabel.getHeight() + 5, t.getPreferredSize().width + 5,
					t.getPreferredSize().height);
			addExpense.add(t);

			ButtonGroup type = new ButtonGroup();
			JPanel typePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
			typePanel.setLocation(t.getX() + t.getWidth() + 5, t.getY());
			typePanel.setSize(addExpense.getWidth() - typePanel.getX(), 30);
			typePanel.setAlignmentX(Component.LEFT_ALIGNMENT);
			for (int i = 0; i < Expense.type.length; i++) {
				JRadioButton expenseType = new JRadioButton(Expense.type[i]);
				expenseType.setActionCommand(i + "");

				type.add(expenseType);
				typePanel.add(expenseType);
			}

			addExpense.add(typePanel);

			JLabel billingDay = new JLabel("Expense Incurred/Billing Day (of month) ");
			billingDay.setBounds(5, typePanel.getY() + typePanel.getHeight() + 5,
					billingDay.getPreferredSize().width + 15, billingDay.getPreferredSize().height);
			JTextField dayField = new JTextField(10);
			dayField.setBounds(billingDay.getX() + billingDay.getWidth() + 5, billingDay.getY(),
					dayField.getPreferredSize().width, dayField.getPreferredSize().height);
			addExpense.add(billingDay);
			addExpense.add(dayField);

			JLabel billingMonth = new JLabel("Incurred/Billing Month (1-12)");
			billingMonth.setBounds(5, billingDay.getY() + billingDay.getHeight() + 5,
					billingMonth.getPreferredSize().width + 10, billingMonth.getPreferredSize().height);

			JTextField monthField = new JTextField(10);
			monthField.setBounds(billingMonth.getX() + billingMonth.getWidth() + 5, billingMonth.getY(),
					monthField.getPreferredSize().width, monthField.getPreferredSize().height);
			addExpense.add(billingMonth);
			addExpense.add(monthField);

			JLabel billingYear = new JLabel("Year");
			billingYear.setBounds(5,billingMonth.getY()+billingMonth.getHeight()+5,
					billingYear.getPreferredSize().width+5,billingMonth.getPreferredSize().height);
			JTextField yearField = new JTextField(10);
			yearField.setBounds(billingYear.getX()+billingYear.getWidth()+5,
					billingYear.getY(),yearField.getPreferredSize().width,
					yearField.getPreferredSize().height);
			addExpense.add(billingYear);
			addExpense.add(yearField);
			
			JButton addButton = new JButton("Add");
			addButton.setSize(addButton.getPreferredSize().width + 5, addButton.getPreferredSize().height);
			addButton.setLocation(addExpense.getWidth() / 2 - addButton.getWidth() / 2,
					addExpense.getY() - addButton.getHeight() -10);
			addButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					String tempname = nameField.getText();
					if (tempname.trim().equals("")) {
						createErrorFrame("Please enter an expense name.");
						return;
					}
					tempname = tempname.replaceAll(" ", "_");
					String s = amountField.getText();
					double amount;
					try {
						amount = Double.parseDouble(s);
					} catch (NumberFormatException n) {
						createErrorFrame("Please enter a number in amount field.");
						return;
					}
					int frequencyChoice = -1;
					for (Enumeration<AbstractButton> i = freq.getElements(); i.hasMoreElements();) {
						AbstractButton button = i.nextElement();
						if (button.isSelected()) {
							frequencyChoice = Integer.parseInt(((button).getActionCommand()));
						}
					}
					if (frequencyChoice == -1) {
						createErrorFrame("Please choose a frequency type.");
						return;
					}
					int typeChoice = -1;
					for (Enumeration<AbstractButton> i = type.getElements(); i.hasMoreElements();) {
						AbstractButton button = i.nextElement();
						if (button.isSelected()) {
							typeChoice = Integer.parseInt((button).getActionCommand());
						}
					}
					if (typeChoice == -1) {
						createErrorFrame("Please choose an expense type.");
						return;
					}
					int expenseDueDay = -1, expenseDueMonth = -1,expenseDueYear=-1;
					try {
						expenseDueDay = Integer.parseInt(dayField.getText());
						if(expenseDueDay<1) {
							createErrorFrame("Please enter a valid number in Day field.");
							return;
						}
						
					} catch (NumberFormatException n) {
						createErrorFrame("Please enter a number in Day field.");
						return;
					}
					//if expense is a monthly expense, the month does not matter
					if (typeChoice != 2) {
						try {
							expenseDueMonth = Integer.parseInt(monthField.getText());
							if(expenseDueMonth<1) {
								createErrorFrame("Please enter a valid number in Month field.");
								return;
							}
							
						} catch (NumberFormatException n) {
							createErrorFrame("Please enter a number in Month field.");
							return;
						}
					}

					//if expense if one time, then the year matters
					if(typeChoice == 3) {
						try {
							expenseDueYear = Integer.parseInt(yearField.getText());
						}catch(NumberFormatException n) {
							createErrorFrame("Please enter a number in Year field.");
							return;
						}
					}
					
					if (typeChoice == 2) {
						// 28th is the maximum day of the month that can be valid for monthly
						// expenses, anything over will just be 28
						expenseDueDay = Math.min(28, expenseDueDay);
					}
					if (typeChoice != 2) {
						if (!CalendarGUI.validDate(expenseDueDay, expenseDueMonth)) {
							createErrorFrame("Please enter a valid date.");
							return;
						}
					}
					expenses.add(
							////////////////////temp
							new Expense(tempname, amount, frequencyChoice, typeChoice,
									expenseDueDay, expenseDueMonth,expenseDueYear));
					getEditMenu();
					SwingUtilities.getRoot(editMenu).revalidate();
					SwingUtilities.getRoot(editMenu).repaint();
					addExpense.dispose();
				}
			});

			addExpense.add(addButton);
			addExpense.setVisible(true);
		}
	}
    /*
	// used for testing purposes
	public void addExpense(String name, double amount, int durationType, int expenseType, int day, int month,int year) {
		expenses.add(new Expense(name, amount, durationType, expenseType, day, month,year));
	}
	*/
	/**
	 * Sort expenses by name, A-Z case independent
	 */
	public void sortExpensesByName() {
		Expense.sortExpense(expenses,new Expense.NameCompare());
	}
	/**
	 * Sort expenses by amount, from least to greatest
	 */
	public void sortExpensesByAmount() {
		Expense.sortExpense(expenses,new Expense.AmountCompare());
	}
	
	private void createErrorFrame(String text) {
		JFrame warning = new JFrame("Error");
		JTextArea message = new JTextArea(text);
		message.setLineWrap(true);
		message.setWrapStyleWord(true);
		warning.add(message);
		warning.setSize(250, 100);
		warning.setLocationRelativeTo(null);
		warning.setVisible(true);
	}
}
